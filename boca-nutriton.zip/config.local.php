<?php

return array (
  'database' => 
  array (
    'driver' => 'mysql',
    'table_prefix' => '',
    'sqlite' => 
    array (
      'database' => 'D:\\Projetos\\php\\github-clones\\boca-modelo/database/database.sqlite',
    ),
    'mysql' => 
    array (
      'host' => '177.234.154.90',
      'database' => 'ciriusdev_bocamodelo',
      'username' => 'ciriusdev_projetosemphp',
      'password' => 'g7JEwURVbl8Pbc79',
      'charset' => 'utf8mb4',
      'collation' => 'utf8mb4_unicode_ci',
    ),
  ),
);
